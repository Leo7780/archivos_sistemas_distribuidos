import socket

# Configuración de servidores remotos
# IMPORTANTE: Cambia las IPs por las direcciones reales de tus máquinas virtuales/equipos físicos
SERVIDORES = {
    'suma': ('192.168.120.140', 65431),
    'resta': ('192.168.120.134', 65432),
    'multiplica': ('192.168.120.137', 65433),
    'divide': ('192.168.120.137', 65433), #IPS ESPECIFICAS DE LAS MAQUINAS MODIFICADAS
    'potencia': ('192.168.120.139', 65434), # NUEVO SERVICIO AGREGADO
}

def verificar_servidor(host, puerto):
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(1.5)
            s.connect((host, puerto))
            return True
    except:
        return False

def enviar_operacion(operacion, host, puerto):
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.connect((host, puerto))
            s.sendall(operacion.encode())
            return s.recv(1024).decode()
    except Exception as e:
        # Se corrigió el error de salto de línea usando \n
        return f"Error de conexión con {host}:{puerto}\n{str(e)}"

def actualizar_operaciones_disponibles(operaciones_disponibles):
    cambios = False
    for operacion, (host, puerto) in SERVIDORES.items():
        if operacion not in operaciones_disponibles:
            if verificar_servidor(host, puerto):
                operaciones_disponibles[operacion] = (host, puerto)
                print(f"🟢 Servidor de '{operacion}' ahora está DISPONIBLE.")
                cambios = True
    if cambios:
        print("🔧 Operaciones disponibles actualizadas:", ", ".join(sorted(operaciones_disponibles.keys())))

def cliente():
    print("Verificando disponibilidad de servidores...\n")
    
    operaciones_disponibles = {}

    for operacion, (host, puerto) in SERVIDORES.items():
        if verificar_servidor(host, puerto):
            operaciones_disponibles[operacion] = (host, puerto)
            print(f"✅ Servidor de '{operacion}' disponible en {host}:{puerto}")
        else:
            print(f"❌ Servidor de '{operacion}' NO disponible en {host}:{puerto}")
    
    if not operaciones_disponibles:
        print("\n🚫 Ningún servidor está disponible actualmente.")
        return

    print("\n🔧 Operaciones disponibles:", ", ".join(sorted(operaciones_disponibles.keys())))
    print("Ejemplo: suma 3 4 | resta 10 2 | multiplica 5 6 | divide 8 2 | potencia 2 3")
    print("Escribe 'salir' para cerrar el cliente.")

    while True:
        operacion = input("\nIngrese la operación: ").strip().lower()
        
        if not operacion:
            continue
            
        if operacion == 'salir':
            print("Cerrando el cliente...")
            break

        comando = operacion.split()[0]
        if comando in operaciones_disponibles:
            host, puerto = operaciones_disponibles[comando]
            resultado = enviar_operacion(operacion, host, puerto)
            print(f"Resultado: {resultado}")
        else:
            print("⚠️ Operación no válida o el servidor no está disponible.")

        # Revisar si nuevos servidores se han activado
        actualizar_operaciones_disponibles(operaciones_disponibles)

if __name__ == "__main__":
    cliente()