import socket
import threading

HOST = '192.168.120.139' #IP DE MAQUINA CON EL SERVICIO DE POTENCIA
PORT = 65434  # Puerto para el servidor de potencia

def procesar_operacion(conn):
    while True:
        data = conn.recv(1024)
        if not data:
            break
        operacion = data.decode()
        if operacion == 'exit':
            break

        print(f"[SERVIDOR POTENCIA] Operacion recibida: {operacion}")
        
        try:
            _, a, b = operacion.split()
            a, b = float(a), float(b)
            resultado = str(a ** b) # Operación de exponente
        except Exception as e:
            resultado = f"Error: {str(e)}"
        
        conn.sendall(resultado.encode())
    
    conn.close()

def servidor_potencia():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind((HOST, PORT))
        s.listen()
        print(f"[SERVIDOR POTENCIA] Escuchando en {HOST}:{PORT}...")
        
        while True:
            conn, addr = s.accept()
            print(f"[SERVIDOR POTENCIA] Conectado con {addr}")
            threading.Thread(target=procesar_operacion, args=(conn,)).start()

if __name__ == "__main__":
    servidor_potencia()