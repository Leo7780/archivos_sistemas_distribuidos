import socket
import threading

HOST = '192.168.120.140' #SE CAMBIO LA IP POR LA DEL EQUIPO PARA QUE PUEDA TENER COMUNICACION ENTRE EL CLIENTE Y EL SERVIDOR
PORT = 65431  # Puerto para el servidor de suma

def procesar_operacion(conn):
    while True:
        data = conn.recv(1024)
        if not data:
            break
        operacion = data.decode()
        if operacion == 'exit':
            print("[SERVIDOR SUMA] Comando 'exit' recibido. Cerrando conexión...")
            break

        print(f"[SERVIDOR SUMA] Operacion recibida: {operacion}")
        
        # Realizar la suma
        try:
            _, a, b = operacion.split()
            a, b = float(a), float(b)
            resultado = str(a + b)
        except Exception as e:
            resultado = f"Error: {str(e)}"
        
        conn.sendall(resultado.encode())
    
    conn.close()

def servidor_suma():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind((HOST, PORT))
        s.listen()
        print(f"[SERVIDOR SUMA] Escuchando en {HOST}:{PORT}...")
        
        while True:
            conn, addr = s.accept()
            print(f"[SERVIDOR SUMA] Conectado con {addr}")
            threading.Thread(target=procesar_operacion, args=(conn,)).start()

if __name__ == "__main__":
    servidor_suma()
